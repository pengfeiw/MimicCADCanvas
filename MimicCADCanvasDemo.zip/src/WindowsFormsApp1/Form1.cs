﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Diagram;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.diagramControl1.BackColor = System.Drawing.Color.Black;
            this.diagramControl1.m_Entities.Add(new DLineStrip(new PointF(10, 10), new PointF(20, 20)));
            this.diagramControl1.m_Entities.Add(new DText("吴营生", new PointF(40, 60)));
            this.diagramControl1.m_Entities.Add(new DDottedLine(new PointF(100, 30), new PointF(0, 100)));

            DCircle circle = new DCircle(new PointF(60, 60), 20);
            circle.m_Color = System.Drawing.Color.Green;

            this.diagramControl1.m_Entities.Add(circle);

            this.diagramControl1.ViewAll();
        }
    }
}
